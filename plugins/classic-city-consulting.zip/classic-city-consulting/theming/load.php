<?php
require('remove-emojis.php');
require('custom-image-sizes.php');
require('theme-options-pages.php');
require('theme-json.php');
require('body-classes.php');
require('allow-svgs.php');
