<?php

// Taxonomy
// --- None

// CPTs
include('cpt/testimonial.php');

// ACF
include('acf/testimonials.php');
include('acf/testimonials-block.php');

// Classes
include('classes/class.Testimonial.php');

// Blocks
include('blocks/blocks.php');