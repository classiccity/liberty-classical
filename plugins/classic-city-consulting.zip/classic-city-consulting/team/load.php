<?php

// Taxonomy
include('tax/department.php');

// CPTs
include('cpt/people.php');

// ACF
include('acf/people.php');
include('acf/department.php');

// Classes
include('classes/class.TeamCore.php');
include('classes/class.TeamPerson.php');
include('classes/class.TeamDepartment.php');

// Blocks
include('blocks/blocks.php');