<?php

define("CCC_ACF_BLOCK_PATH",plugin_dir_path(__FILE__));

// ACF Blocks
include('blocks.categories.php');
include('blocks.blocks.php');
include('blocks.fields.php');
//include('blocks.enqueue');
